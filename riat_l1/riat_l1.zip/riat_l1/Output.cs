﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace riat_l1
{
    public class Output
    {
        public decimal SumResult {get; set;}
        public int MulResult {get; set;}
        public decimal[] SortedInputs {get; set;}
    }
}
